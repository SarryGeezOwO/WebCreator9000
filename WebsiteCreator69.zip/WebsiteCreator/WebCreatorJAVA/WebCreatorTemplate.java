public class WebCreatorTemplate {
    public static void main(String[] args) {
        new Creator();
    }
}
